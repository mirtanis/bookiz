CREATE DATABASE  IF NOT EXISTS `bookiz` /*!40100 DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bookiz`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7a103.p.ssafy.io    Database: bookiz
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `book_id` int unsigned NOT NULL AUTO_INCREMENT,
  `cnt` int unsigned NOT NULL,
  `createdate` datetime(6) DEFAULT NULL,
  `image` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `info` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `page` int unsigned DEFAULT NULL,
  `title` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (34,1013,'2022-09-30 15:01:50.000000','https://j7a103.p.ssafy.io/api/books/display?image=금도끼은도끼표지.jpg&id=34','신이담(神異譚)에 속하는 설화 유형의 하나이다. ‘금도끼 은도끼 쇠도끼’ 혹은 ‘정직한 나무꾼’ 등으로 일컬어지기도 합니다.\n\n이 이야기에서 나타내고자 하는 것은 정직 또는 선의 승리라고 할 수 있고, 정직한 자와 부정직한 자, 곧 선과 악의 2원칙인 대비에서는 후자가 실패하게 함으로써 교훈적 의도를 분명히 드러내고 있다.',45,'금도끼 은도끼'),(39,8,'2022-10-04 15:42:40.000000','https://j7a103.p.ssafy.io/api/books/display?image=개구리 왕자.png&id=39','어느 날 아주 아리따운 공주가 금으로 만들어진 공을 가지고 숲에서 놀다가,실수로 공을 샘에 떨어뜨렸다. \n마침 그 샘에 있던 개구리가 이를 보고 공주에게 가서 자신이 공을 찾아주겠노라 한다.\n',15,'개구리 왕자'),(40,46,'2022-10-04 15:42:43.000000','https://j7a103.p.ssafy.io/api/books/display?image=걸리버 여행기.png&id=40','의사 걸리버가 선의(船醫)로 취직해 세계를 돌아다니다 작은 사람들이 사는 나라 릴리퍼트, 큰 사람들이 사는 나라 브로브딩내그, 날아다니는 섬의 나라 라퓨타, 말(馬) 모양을 한 지성체 후이넘이 지배하는 나라를 방문하게 되는 기행문 형식을 띤 소설이다.',4,'걸리버 여행기'),(41,3,'2022-10-04 10:56:55.000000','https://j7a103.p.ssafy.io/api/books/display?image=미운오리 새끼 표지.png&id=41','옛날 어느 못가에 금슬 좋은 오리 부부 한 쌍이 살고 있었다. \n이들은 사랑을 나눈 결실로 알 여러 개를 낳았는데, 유독 크고 못생긴 알 하나가 둥지 틈에 끼어 있었다. \n오리 부부는 그 알을 보고 처음엔 의아해했으나 그저 조금 크게 태어난 알일 것이라 생각하고 별 고민없이 알을 품었다.\n',12,'미운 오리 새끼'),(42,15,'2022-10-04 15:42:41.000000','https://j7a103.p.ssafy.io/api/books/display?image=이상한 나라의 엘리스 책표지.png&id=42','언니와 소풍을 온 앨리스는 시계를 보며 늦었다고 소리치는 토끼를 봅니다. \n앨리스는 토끼를 크게 부르지만 토끼는 듣지 못합니다. \n토끼를 따라간 앨리스는 토끼가 구멍 안으로 들어가는 것을 보고 따라 들어가게 됩니다\n',16,'이상한 나라의 앨리스'),(43,11,'2022-10-04 10:58:02.000000','https://j7a103.p.ssafy.io/api/books/display?image=인어 공주 책표지.png&id=43','깊은 바다 속 용왕에겐 7명의 딸들이 있었는데, 그들은 15살이 되어야만 육지로 구경을 갈 수 있었다. \n그 중 막내 인어공주는 육지에 대한 환상과 갈망이 가장 많았다. \n마침내 그녀의 15번째 생일이 다가오고, 그녀는 바다 위로 올라갈 수 있게 되었다.\n',8,'인어공주'),(45,10,'2022-10-04 10:58:37.000000','https://j7a103.p.ssafy.io/api/books/display?image=잠자는 숲속의 공주.png&id=45','아이를 간절히 원하던 어느 왕과 왕비가 귀여운 딸을 얻게 되었다. \n공주의 탄생을 축하하기 위해 왕은 나라안의 마법사를 초대하기로 했다. \n손님을 대접할 황금 접시가 12개밖에 없었기 때문에 부득이하게 왕은 열두 명의 마법사밖에 초대할 수가 없었다. \n\n',6,'잠자는 숲속의 공주'),(46,14,'2022-10-04 15:42:43.000000','https://j7a103.p.ssafy.io/api/books/display?image=잭과 콩나무 표지.png&id=46','옛날 옛적 어느 곳에 과부가 된 어머니와 가난한 소년 잭이 농장 오두막에서 살고 있었다. \n젖소가 유일한 수입원이었는데, 젖소에게서 더는 우유가 나오지 않자 잭의 어머니는 소를 시장에 데려가 팔라고 말한다. \n게으름뱅이 잭은 길을 가다가 만난 남자로부터 콩과 소를 교환한다. \n',12,'잭과 콩나무'),(47,20,'2022-10-04 10:59:40.000000','https://j7a103.p.ssafy.io/api/books/display?image=peter-pan-g82d38f386_1920.jpg&id=47','피터팬은 영원히 어른이 되지 않는 네버랜드에 살고 있다.\n네버랜드에는 어렸을 때 부모님을 잃고 이 곳에 오게 된 여러 아이들이 있고\n피터팬은 그 아이들의 대장으로 불리며 아이들의 엄마가 되어 줄 사람을 구하러 네버랜드에서 나오게 된다. \n',9,'피터팬'),(48,3,'2022-10-04 15:32:49.000000','https://j7a103.p.ssafy.io/api/books/display?image=빨간모자 책표지.png&id=48','숲 속 할머니네 집에 찾아간 빨간모자는 늑대를 마주하게 되는데!',2,'빨간모자'),(49,8,'2022-10-04 15:34:30.000000','https://j7a103.p.ssafy.io/api/books/display?image=신데렐라 책표지.png&id=49','몰래 파티장에 놀러 갔다가 유리구두를 놓고 온 신데렐라!\n과연 어떻게 될까요?',2,'신데렐라'),(50,49,'2022-10-04 15:42:40.000000','https://j7a103.p.ssafy.io/api/books/display?image=백설공주 책표지.png&id=50','백설공주의 아름다움을 질투하는 마녀 왕비로부터 백설공주는 무사할 수 있을까요?',11,'백설공주');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  9:28:19
